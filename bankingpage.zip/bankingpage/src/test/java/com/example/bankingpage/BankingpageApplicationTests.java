package com.example.bankingpage;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BankingpageApplicationTests {

	@Test
	void contextLoads() {
	}

}
